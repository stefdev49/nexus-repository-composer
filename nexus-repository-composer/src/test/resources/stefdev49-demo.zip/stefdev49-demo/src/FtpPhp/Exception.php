<?php

namespace FtpPhp;

class Exception extends \Exception
{
} 
